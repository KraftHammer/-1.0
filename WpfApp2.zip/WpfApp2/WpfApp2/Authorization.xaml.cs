﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    public partial class Authorization : Window
    {
        public Authorization()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = "Server=ALEX;Database=CafeDB;Integrated Security=True;\r\n";
            string login = txtbox_1.Text;
            string password = txtbox_2.Text;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                // Запрос для проверки логина и пароля
                string query = "SELECT COUNT(*) FROM База_пользователей WHERE Логин = @login AND Пароль = @password";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@login", login);
                    command.Parameters.AddWithValue("@password", password);

                    int userCount = (int)command.ExecuteScalar();

                    if (userCount > 0)
                    {
                        if (admin_check.IsChecked == true)
                        {
                            Admin_Window adminForm = new Admin_Window();
                            adminForm.Show();
                        }
                        else
                        {
                            Main userForm = new Main(); 
                            userForm.Show();
                        }
                        this.Close(); 
                    }
                    else
                    {
                        MessageBox.Show("Неверный логин или пароль.");
                    }
                }
            }
        }

        private void Login_btn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
    }
}
